# FABLEBREAKER-AGI Agent Workspace Seed

Drop this bundle into the repository root.

Main file:
- `.github/agents/alpha-medina-architecture.agent.md`

Support files:
- `docs/architecture/alpha-medina-engine-stack.md`
- `docs/architecture/public-private-translation.md`
- `skills/manifest.json`

Prompt body characters: 29973
Total agent file characters: 30573

This version treats the agent as a working-space kernel: root orchestration, engines, skills, specialist-agent routing, materialization queues, validation standards, and public/private translation.
