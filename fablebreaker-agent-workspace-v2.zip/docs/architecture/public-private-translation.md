# Public / Private Translation Map

Use this map when converting internal doctrine into public-facing GitHub files.

| Internal | Public-safe default |
|---|---|
| organism | adaptive system / operating unit / multi-agent architecture |
| organism company | adaptive company architecture / multi-unit operating platform |
| heartbeat | coordination loop / runtime cadence |
| closed-loop pair | human-AI operating loop |
| creator-view | founder/operator control layer |
| God-view | do not use publicly |
| false god collapse | interface-governance inversion / control hierarchy error |
| synthetic life | adaptive synthetic entity system |
| AGI | adaptive intelligence system unless AGI is explicitly required |
| doctrine | architecture principles / operating framework |
